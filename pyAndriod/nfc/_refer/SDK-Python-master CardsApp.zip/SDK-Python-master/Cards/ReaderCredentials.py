class ReaderCredentials:
    """Reader Credentials Class"""
    def __init__(self, api_key):
        self.api_key = api_key