class ReaderSettings:
    """Reader Settings Class"""
    def __init__(self, device_name):
        self.device_name = device_name