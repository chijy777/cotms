Kivy Blueprints
===============
This is the source code for the book [Kivy Blueprints][1] by [Mark Vasilkov][2], published by Packt in 2015.

Corrections are warmly welcome.

[1]: https://www.packtpub.com/application-development/kivy-blueprints
[2]: http://mvasilkov.name
