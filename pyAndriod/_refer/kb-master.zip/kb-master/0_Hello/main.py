from kivy.app import App


class HelloApp(App):
    pass

if __name__ == '__main__':
    HelloApp().run()
